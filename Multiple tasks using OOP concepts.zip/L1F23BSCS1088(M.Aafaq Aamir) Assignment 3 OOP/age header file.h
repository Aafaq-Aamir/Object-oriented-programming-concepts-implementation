#pragma once
#ifndef AGE_H
#define AGE_H
#include<iostream>
using namespace std;
class Age {
private:
    int Y, M, D;
public:
    Age(int years, int months, int days);       //Parameterized Constructor 
    // Overload the stream insertion operator for display age
    friend ostream& operator<<(ostream& out, const Age& a);
    int calculateTotalDays() const;     //for calculating total number of days
};
#endif
