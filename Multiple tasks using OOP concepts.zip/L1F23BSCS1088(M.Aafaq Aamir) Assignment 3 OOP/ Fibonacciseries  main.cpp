#include <iostream>
#include "FibonacciSeries.h"
using namespace std;
int main() {
    int choice;
    // Start the do-while loop to keep showing the menu
    do {
        // Display menu options
        cout << "-------------------------------------------------------" << endl;
        cout << "                         Menu:" << endl;
        cout << "-------------------------------------------------------" << endl;
        cout << "Press '1' to Generate Fibonacci series (up to N terms)" << endl;
        cout << "Press '2' to Generate Fibonacci series (from fixed starting term to ending term)" << endl;
        cout << "Press '3' to Exit!!" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        // Handle different choices
        if (choice == 1) {
            int terms;
            cout << "How many terms of the Fibonacci series you want to generate: ";
            cin >> terms;
            Fibonacci fib(0, 1);  // Initialize object with 0 and 1
            fib.generateseries(terms);
        }
        else if (choice == 2) {
            // Scenario 2: User specifies starting and ending terms
            int start, end;
            cout << "Enter Starting term of the series: ";
            cin >> start;
            cout << "Enter Ending term of the series: ";
            cin >> end;
            Fibonacci fib(0, 1);  // Initialize object with 0 and 1
            fib.generateseriesinrange(start, end);
        }
        else if (choice == 3) { 
            cout << "...Exiting program..." << endl;
        }
        else {
            cout << "please entre a valid choice" << endl;
        }
    } while (choice != 3); 
    //if the user choose 3 it will exit the loop(keep running until choice=3)
    return 0;
}
