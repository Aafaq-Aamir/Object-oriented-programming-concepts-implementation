#define _CRT_SECURE_NO_WARNINGS  // using define crt secure no warnings bcz visual studio 2019 is not supporting strcpy
#include "Product.h"
#include <iostream>
#include <cstring>
// Base class Package
Package::Package(const char* senderName, const char* senderAddress, const char* senderCityStateZip,
    const char* recipientName, const char* recipientAddress, const char* recipientCityStateZip,
    double weight, double costPerOunce) {
    strcpy(this->senderName, senderName);    // Copy the sender's name to the senderName member variable using strcpy
    strcpy(this->senderAddress, senderAddress);  // Copy the sender's address to the senderadress member variable using strcpy
    strcpy(this->senderCityStateZip, senderCityStateZip);    // Copy the sender's zip code to the sender zip code member variable using strcpy
    strcpy(this->recipientName, recipientName);     //copying recipitent name 
    strcpy(this->recipientAddress, recipientAddress);   //copying recipitent addres
    strcpy(this->recipientCityStateZip, recipientCityStateZip);     //copying recipitent city zip code
    this->weight = weight;      //bcz it is in double datatype
    this->costPerOunce = costPerOunce;      //bcz it is in double datatype
}
double Package::calculateCost() const {
    int cost;
    cost = weight * costPerOunce;
    return cost;
}
ostream& operator<<(ostream& out, const Package& p) {
    out << "Sender: "<<endl << p.senderName << endl << p.senderAddress << endl << p.senderCityStateZip << endl<<endl;
    out << "Recipient: "<<endl << p.recipientName << endl << p.recipientAddress << endl << p.recipientCityStateZip << endl<<endl;
    out << "Weight: " << p.weight << " oz"<<endl;
    out << "Cost per ounce: $" << p.costPerOunce << endl;
    out << "Shipping Cost: $" << p.calculateCost() << endl;
    return out;
}
// Derived class OvernightPackage
//parameterized constructor for the overnight package class
OvernightPackage::OvernightPackage(const char* senderName, const char* senderAddress,
    const char* senderCityStateZip,const char* recipientName, const char* recipientAddress,
    const char* recipientCityStateZip,double weight, double costPerOunce,
    double additionalFeePerOunce)
    // Initialize the base class members by calling the base class constructor manually
    :Package(senderName, senderAddress, senderCityStateZip, recipientName, recipientAddress, recipientCityStateZip,
        weight, costPerOunce), additionalFeePerOunce(additionalFeePerOunce) {}
double OvernightPackage::calculateCost() const {
    double rate = weight * additionalFeePerOunce;
    return Package::calculateCost() +rate;
}
ostream& operator<<(ostream& out, const OvernightPackage& op) {
    out << (Package)op;
    out << "Additional Fee per Ounce: $" << op.additionalFeePerOunce << endl;
    out << "Total Cost: $" << op.calculateCost() << endl;
    return out;
}
// Derived class TwoDayPackage
TwoDayPackage::TwoDayPackage(const char* senderName, const char* senderAddress, const char* senderCityStateZip,
    const char* recipientName, const char* recipientAddress, const char* recipientCityStateZip,
    double weight, double costPerOunce, double flatFee)
    : Package(senderName, senderAddress, senderCityStateZip, recipientName, recipientAddress, recipientCityStateZip,
        weight, costPerOunce), flatFee(flatFee) {}
double TwoDayPackage::calculateCost() const {
    return Package::calculateCost() + flatFee;
}
ostream& operator<<(ostream& out, const TwoDayPackage& tp) {
    out << (Package)tp;
    out << "Flat Fee: $" << tp.flatFee << endl;
    out << "Total Cost: $" << tp.calculateCost() << endl;
    return out;
}
 