#pragma once
#ifndef PRODUCT_H
#define PRODUCT_H
#include <iostream> //header files
#include <cstring>
using namespace std;
class Package {
protected:
    char senderName[100];
    char senderAddress[100];
    char senderCityStateZip[100];
    char recipientName[100];
    char recipientAddress[100];
    char recipientCityStateZip[100];
    double weight;  // in ounces
    double costPerOunce; // in dollars
public:
    Package(const char* senderName, const char* senderAddress, const char* senderCityStateZip,
        const char* recipientName, const char* recipientAddress, const char* recipientCityStateZip,
        double weight, double costPerOunce);
    double calculateCost() const;
    friend ostream& operator<<(ostream& out, const Package& p);
};

// Derived class OvernightPackage
class OvernightPackage : public Package {
private:
    double additionalFeePerOunce;
public:
    OvernightPackage(const char* senderName, const char* senderAddress, const char* senderCityStateZip,
        const char* recipientName, const char* recipientAddress, const char* recipientCityStateZip,
        double weight, double costPerOunce, double additionalFeePerOunce);
    double calculateCost() const;
    friend ostream& operator<<(ostream& out, const OvernightPackage& op);
};

// Derived class TwoDayPackage
class TwoDayPackage : public Package {
private:
    double flatFee;
public:
    TwoDayPackage(const char* senderName, const char* senderAddress, const char* senderCityStateZip,
        const char* recipientName, const char* recipientAddress, const char* recipientCityStateZip,
        double weight, double costPerOunce, double flatFee);
    //function to calculate total cost 
    double calculateCost() const;
    //overloading assignment operator using the friend function
    friend ostream& operator<<(ostream& out, const TwoDayPackage& tp);
};
#endif
