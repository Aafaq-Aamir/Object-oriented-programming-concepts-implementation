#include "FibonacciSeries.h"    //user defined header file
#include <iostream>
using namespace std;
// Constructor to initialize start and end terms of the Fibonacci series
Fibonacci::Fibonacci(int start, int end) {
    startingterm = start;
    endingterm = end;
}
// Overloading ++ operator to generate the next Fibonacci number by adding the previous one in it
Fibonacci& Fibonacci::operator++() {
    int nextterm;
    nextterm= startingterm + endingterm;
    startingterm = endingterm;
    endingterm = nextterm;
    return *this;       //returning the updated object (next term)
}
// Function to generate and print the Fibonacci series up to a fixed number of terms
void Fibonacci::generateseries(int terms) {
    //if the choice is zero or lesser than zero
    if (terms <= 0) {
        cout << "Please enter a valid number of terms (greater than 0)." << endl;
        return;
    }
    cout << "Fibonacci series up to the " << terms << "th term is displayed below:" << endl;
    // Print the first term (initialize before the loop) as 1
    if (terms >= 1) cout << startingterm << " ";  // 1st term '0'
    if (terms >= 2) cout << endingterm << " ";   // 2nd term '1'
    for (int i = 3; i <= terms; ++i) { // Start from the 3rd term
        ++(*this);  // Generate the next Fibonacci number by adding the previous one in it 
        cout << endingterm << " ";
    }
    cout << endl;
}
void Fibonacci::generateseriesinrange(int start, int end) {
    // Check if the start and end values are valid
    if (start > end || start <= 0 || end <= 0) {
        cout << "Invalid range! Please ensure start <= end and both are greater than 0." << endl;
        return;
    }
    cout << "Fibonacci series from " << start << "th term to " << end << "th term is: ";
    // Move to the starting term
    for (int i = 1; i < start; ++i) {
        ++(*this);  // Generate the next Fibonacci term
    }
    // Print the Fibonacci terms from start to end
    for (int i = start; i <= end; ++i) {
        cout << endingterm << " ";
        ++(*this);  // Generate the next Fibonacci term
    }
    cout << endl;
}
