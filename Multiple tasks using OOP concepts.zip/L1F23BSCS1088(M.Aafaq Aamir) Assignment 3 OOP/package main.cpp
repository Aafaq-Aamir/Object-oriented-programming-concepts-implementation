#include <iostream>
#include "Product.h"
using namespace std;
int main() {
    //displaying as given in samples
    //for 2 days package 
    cout << "Sample Run 1: Two-Day Package"<<endl;
    TwoDayPackage twoDayPackage("Lou Brown", "1 Main Street", "Boston, MA 1111",
        "Marry Smith", "7 Elm St", "New York, NY 22222", 10.0, 0.50, 5.00);  //as provided 
    cout << twoDayPackage << endl;  // Display package details 1
    cout << "Total Shipping Cost: $" << twoDayPackage.calculateCost() << endl ;
    cout << endl;
    cout << endl;
    // for overnight package
    cout << "Sample Run 2: Overnight Package"<<endl;
    OvernightPackage overnightPackage("Lou Brown", "1 Main Street", "Boston, MA 1111",
        "Marry Smith", "7 Elm St", "New York, NY 22222",10.0, 0.50, 0.25);  //as provided
    cout << overnightPackage << endl;  // Display package details
    cout << "Total Shipping Cost: $" << overnightPackage.calculateCost() <<endl;
    return 0;
}