#include "Age.h"
// Constructor to initialize the age
Age::Age(int years, int months, int days) {
    Y = years;
    M = months;
    D = days;
}
// Overload the << operator to display the age
    ostream& operator<<(ostream& output, const Age& a) {
    output << a.Y << " years, ";
    output << a.M << " months, and ";
    output<< a.D << " days";
    return output;
}
// Function to calculate total days
int Age::calculateTotalDays() const {
    int DAYS= (Y * 365) + (M * 30) + D;     //1 year =365 days & 1 month =30 days
    return DAYS;
}
