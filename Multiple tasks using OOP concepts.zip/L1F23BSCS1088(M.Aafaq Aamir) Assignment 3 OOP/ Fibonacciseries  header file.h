#pragma once
#ifndef FIBONACCI_H
#define FIBONACCI_H
class Fibonacci {
private:
    int startingterm;  // First term in the Fibonacci series
    int endingterm;    // Second term in the Fibonacci series
public:
    Fibonacci(int start, int end);  //Constructor to initialize the starting and ending term of series
    // Overload ++ operator to generate the next Fibonacci number
    Fibonacci& operator++();
    // Function to generate and print the Fibonacci series up to fixed terms
    void generateseries(int terms);
    // Function to generate and print the Fibonacci series from a specified range
    void generateseriesinrange(int start, int end);
};
#endif
