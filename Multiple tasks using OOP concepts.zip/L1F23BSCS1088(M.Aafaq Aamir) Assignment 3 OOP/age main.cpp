#include <iostream>
#include "Age.h"
//no need to add using namespace std as it is already included in Age header file
int main() {
    int year, month, day;
    // Input for years, months, and days
    start:
    cout << "-------------------------Age calculator-------------------------"<<endl << endl;
    cout << "Entre years, months, and days(integers only): ";
    cin >> year >> month >> day;
    if (year < 0 || month < 1 || month > 12 || day < 1 || day > 31) {
        cout << "Please enter valid values again!!" << endl;
        goto start;         //using goto statment to deal with invalid inputs
    }
    cout << "The age enetered is: " << year << " years " << month << " months " << day<<" days" << endl;;
    cout << "------------------------------------------------" << endl;
    Age A1(year, month, day);      //object creation
    cout << "Age formatted as: " << A1 << endl;     //using overloaded operator
    cout << "---Calculating total days---"<<endl;
    cout << "Total days: " << A1.calculateTotalDays() << endl;      //calculating total days
    return 0;
}
